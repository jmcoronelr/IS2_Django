from django.apps import AppConfig


class PlantillasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Plantillas'
